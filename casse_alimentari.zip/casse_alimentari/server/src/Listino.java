import java.util.ArrayList;

public class Listino {
    private ArrayList<Prodotto> elencoProdotti;
}
