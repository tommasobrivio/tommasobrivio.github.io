public class Cassiere {
    private String identita;
    
}
