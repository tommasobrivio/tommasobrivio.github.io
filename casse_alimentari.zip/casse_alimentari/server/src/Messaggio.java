public class Messaggio{
    private String comando;
    private Object o; //controllo comando per parsare 
}