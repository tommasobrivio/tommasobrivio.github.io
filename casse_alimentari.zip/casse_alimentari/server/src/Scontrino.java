import java.util.List;

public class Scontrino {
    private Cassiere cassiere;
    private String data;
    private List<Prodotto> prodottiAcquistati;
}
