public class Prodotto {
    private String nomeProdotto;
    private float costoUnitario;
    private int id;


}
