public class ProdottoComprato {
    
}
